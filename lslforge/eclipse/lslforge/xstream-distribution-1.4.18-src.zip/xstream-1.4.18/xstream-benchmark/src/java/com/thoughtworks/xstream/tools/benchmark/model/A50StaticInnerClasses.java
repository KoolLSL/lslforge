/*
 * Copyright (C) 2007, 2009, 2011, 2015 XStream Committers.
 * All rights reserved.
 *
 * The software in this package is published under the terms of the BSD
 * style license a copy of which has been included with this distribution in
 * the LICENSE.txt file.
 * 
 * Created on 15. August 2007 by Joerg Schaible
 */
package com.thoughtworks.xstream.tools.benchmark.model;

/**
 * Class with static inner classes 50 levels deep.
 * 
 * @since 1.4
 * @deprecated As of 1.4.9 use JMH instead
 */
public class A50StaticInnerClasses {

    public static class L00 { String field000;
    public static class L01 { String field001;
    public static class L02 { String field002;
    public static class L03 { String field003;
    public static class L04 { String field004;
    public static class L05 { String field005;
    public static class L06 { String field006;
    public static class L07 { String field007;
    public static class L08 { String field008;
    public static class L09 { String field009;
    public static class L10 { String field010;
    public static class L11 { String field011;
    public static class L12 { String field012;
    public static class L13 { String field013;
    public static class L14 { String field014;
    public static class L15 { String field015;
    public static class L16 { String field016;
    public static class L17 { String field017;
    public static class L18 { String field018;
    public static class L19 { String field019;
    public static class L20 { String field020;
    public static class L21 { String field021;
    public static class L22 { String field022;
    public static class L23 { String field023;
    public static class L24 { String field024;
    public static class L25 { String field025;
    public static class L26 { String field026;
    public static class L27 { String field027;
    public static class L28 { String field028;
    public static class L29 { String field029;
    public static class L30 { String field030;
    public static class L31 { String field031;
    public static class L32 { String field032;
    public static class L33 { String field033;
    public static class L34 { String field034;
    public static class L35 { String field035;
    public static class L36 { String field036;
    public static class L37 { String field037;
    public static class L38 { String field038;
    public static class L39 { String field039;
    public static class L40 { String field040;
    public static class L41 { String field041;
    public static class L42 { String field042;
    public static class L43 { String field043;
    public static class L44 { String field044;
    public static class L45 { String field045;
    public static class L46 { String field046;
    public static class L47 { String field047;
    public static class L48 { String field048;
    public static class L49 { String field049;
    }}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
}
